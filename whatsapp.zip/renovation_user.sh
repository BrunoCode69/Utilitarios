#!/usr/bin/env bash
    usuario=$1
    dias="30"
    finaldate=$(date "+%Y-%m-%d" -d "+$dias days")  
    gui=$(date "+%d/%m/%Y" -d "+$dias days")                                      
    chage -E $finaldate $usuario